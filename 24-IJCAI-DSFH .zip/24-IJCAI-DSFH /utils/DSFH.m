function [ImgToTxt,TxtToImg] = DSFH(trainLabel, param, dataset)
seed = 0;
rng('default');
rng(seed);

X1 = dataset.XDatabase;
X2 = dataset.YDatabase;
XTest = dataset.XTest;
YTest = dataset.YTest;
testL = dataset.testL;
databaseL = dataset.databaseL;

% X1 = NormalizeFea(X1,1);
% X2 = NormalizeFea(X2,1);
trainLabel = NormalizeFea(trainLabel,1);
% XTest = NormalizeFea(XTest,1);
% YTest = NormalizeFea(YTest,1);


[a,~] = kmeans(trainLabel,param.km,'Distance','cosine');
LSet = sparse(1:size(trainLabel,1),a,1);
LSet = full(LSet);


top_K=1000;
[d1,~] = size(X1');
[d2,numTrain] = size(X2');
bits = param.bit;
max_iter = param.maxIter;
lambda = param.lambda;
beta = param.beta;
alpha = param.alpha;

n = size(trainLabel,1);
%--------------------------------initial------------------------------------
% B=ones(numTrain,bits);B=sign(B);
H1 = randn(numTrain,bits);
H2 = randn(numTrain,bits);
tic
for i = 1:max_iter
    %--------- W-step
    [W11,~,SW1] = svd(X1'*H1,'econ');
    P1 = W11*SW1';
    [W22,~,SW2] = svd(X2'*H2,'econ');
    P2 = W22*SW2';
    % update B
    BCluster1 = H1'* LSet*(LSet');
    BCluster2 = H2'* LSet*(LSet');
    Blabel1 = H1'* trainLabel*trainLabel';
    Blabel2 = H2'* trainLabel*trainLabel';
    B = sign(alpha*bits*(beta*(Blabel1'+Blabel2')+(1-beta)*(BCluster1'+BCluster2')));
    % update Ht
    HCluster = B'* LSet*(LSet');        
    Hlabel = B'* trainLabel*trainLabel';
    Htmp1 =  (X1*P1 + alpha* bits * (beta*Hlabel+(1-beta)*HCluster)')';
    H1 = constraint(Htmp1,bits,n);   
    Htmp2 =  (X2*P2 + alpha* bits * (beta*Hlabel+(1-beta)*HCluster)')';
    H2 = constraint(Htmp2,bits,n);   
end

toc

%-----------------real-time evaluation----------------------------
W1=(X1'*X1+lambda*eye(d1))\(X1'*B);
W2=(X2'*X2+lambda*eye(d2))\(X2'*B);
tBX = sign(XTest*W1);
tBY = sign(YTest*W2);
HH=B;
HH(HH<0) = 0;
ti_H = compactbit(HH);
tBX(tBX<0) = 0;
tBX = compactbit(tBX);
tBY(tBY<0) = 0;
tBY = compactbit(tBY);
Dhamm = hammingDist(tBY, ti_H);
[~, HammingRank]=sort(Dhamm,2);
out.MAP_test(1) = cal_mAP(databaseL,testL,HammingRank);
[out.Image_VS_Text_precision, out.Image_VS_Text_recall] = precision_recall(HammingRank',databaseL,testL);
out.Image_To_Text_Precision = precision_at_k(HammingRank', databaseL,testL,top_K);
Dhamm = hammingDist(tBX, ti_H);
[~, HammingRank]=sort(Dhamm,2);
out.MAP_test(2) = cal_mAP(databaseL,testL,HammingRank);
[out.Text_VS_Image_precision, out.Text_VS_Image_recall] = precision_recall(HammingRank', databaseL,testL);
out.Text_To_Image_Precision = precision_at_k(HammingRank', databaseL,testL,top_K);
ImgToTxt=out.MAP_test(1);
TxtToImg=out.MAP_test(2);
fprintf('...iter:%d,   i2t:%.4f,   t2i:%.4f\n',max_iter, ImgToTxt, TxtToImg)
end




