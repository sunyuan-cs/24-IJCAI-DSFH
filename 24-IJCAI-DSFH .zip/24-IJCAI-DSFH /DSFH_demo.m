clear all
warning off
addpath(genpath(fullfile('utils/')));
addpath(genpath(fullfile('dataset/')));
addpath(genpath(fullfile('iapr-partial/')))
seed = 0;
rng('default');
rng(seed);

% bits = [64];
bits = [8,16,32,64]
nb = numel(bits);

param.bits = bits;
param.maxIter = 10;
param.method = 'DSFH';

%-----------------basie information
dataname = 'flickr-25k';
alpha =1e-3;lambda =1e-3;km = 400;
% dataname = 'iapr-tc12';
% alpha =1e-4;lambda =1e-3;km = 300;
% dataname = 'nus-wide-clear';
% alpha =1e-4;lambda =1e-4;km = 400;
% dataname = 'wikiData';
% alpha =1e-3;lambda =1e-3;km = 400;
%parameter search
% alpha = [1e-4,1e-3,1e-2,1e-1,1,10,100];
% lambda = [1e-4,1e-3,1e-2,1e-1];
% km = [100,200,300,400,500]; 

par_1 = numel(km);
par_2 = numel(alpha);
par_4 = numel(lambda);
param.dataname = dataname;
%load dataset
dataset = load_data(dataname);
n_anchors = 1500;
%rbf2;
[n, ~] = size(dataset.YDatabase);
anchor_image = dataset.XDatabase(randsample(n, n_anchors),:);
anchor_text = dataset.YDatabase(randsample(n, n_anchors),:);
dataset.XDatabase = RBF_fast(dataset.XDatabase',anchor_image');
dataset.XTest = RBF_fast(dataset.XTest',anchor_image');
dataset.YDatabase = RBF_fast(dataset.YDatabase',anchor_text');
dataset.YTest = RBF_fast(dataset.YTest',anchor_text');


total_res=[];
% run algorithm
for i = 1: nb
    
    for jj=1:par_2
        
        for jjj=1:par_4
            for kmi=1:par_1
                fprintf('...method: %s\n', param.method);
                fprintf('...bit: %d\n', bits(i));
                param.bit = bits(i);
                param.alpha= alpha(jj);
                param.lambda = lambda(jjj);
                param.km = km(kmi)
                trainL = dataset.databaseL;
                [ImgToTxt,TxtToIm]=DSFH_ww(trainL, param, dataset);
                total_res = [total_res;ImgToTxt,TxtToIm, param.bit, param.alpha, param.lambda,param.km];
            end
        end
        
    end
end

save([dataname, num2str('_results'),'.mat'], 'total_res');


